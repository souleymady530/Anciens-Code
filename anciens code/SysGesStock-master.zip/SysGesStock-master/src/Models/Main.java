/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;

/**
 *
 * @author ofilw
 */
public class Main {

     public static Connection cnx;
    public static PreparedStatement ps;
    public static Statement st;
    public static Statement st2;
    public static ResultSet res;
    public static ResultSet res2;
    public static ImageIcon img;
    public static FileInputStream fis;
    public static File fic;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        // TODO code application logic here
    }
    
}
