<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    use HasFactory;
    
    public $table="les_articles";
    protected $fillable=
    [
        'id',
        "titre",
        "contenu" ,
        "repertoire_image",
        "date_pub",
    ];

    public $timestamps=false;
}
