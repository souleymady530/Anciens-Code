<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    //
    public function make(ContactRequest $request): view
    {
        Mail::to('administrateur@chezmoi.com')
            ->send(new Contact($request->except('_token')));
        return view('contactconfirmed');
    }
}
