<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Article;
use App\Repositories\ArticleRepository;
use App\Htpp\Reauest\CreateArticleRequest;
use App\Htpp\Reauest\UpdateArticleRequest;



class ArticleController extends Controller
{
    protected $nbre_per_page=8;
    protected $aRepos;
    public function __construct(ArticleRepository $aRepos)
    {
        $this->aRepos=$aRepos;
    }


    public function index()
    {
        //
        $all_articles=$this->aRepos->getPaginate($this->nbre_per_page);
        $links=$all_articles->setPath("");
        return view("Articles",compact("all_articles","links"));
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view("CreateArticle");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $foto=$request['repertoire_image'];
		if($foto->isValid())
		{
			$chemin='img';
			do
            
			{
				$nom=date("ymdHis").'.'.$foto->getClientOriginalExtension();
			}
			while(file_exists($chemin.'/'.$nom));
			if($foto->move($chemin,$nom))
			{
                $requete["chemin"]=$chemin.'/'.$nom;
                 //$request['chemin'];
                 $tab["titre"]=$request['titre'];
                 $tab["repertoire_image"]=$chemin.'/'.$nom;
                 $tab['contenu']=$request['contenu'];
                 $tab['date_pub']=strval(date('ymdhis'));
                 $this->aRepos->store($tab);
            }
        
        }
			
    }

    public function show($id)
    {
        //
         
        $article=$this->aRepos->getById($id);
        return view("updateArticle",compact("article"));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //echo"ok";
        $article=$this->aRepos->getById($id);
        return isset($article) && $article!="[]" ? $article:null;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        echo"ok update";
        $foto=$request['chemin'];
		if($foto->isValid())
		{
			$chemin='img';
			do
            
			{
				$nom=date("ymdHis").'.'.$foto->getClientOriginalExtension();
			}
			while(file_exists($chemin.'/'.$nom));
			if($foto->move($chemin,$nom))
			{
                $requete["chemin"]=$chemin.'/'.$nom;
                 //$request['chemin'];
                 $tab["titre"]=$request['titre'];
                 $tab["repertoire_image"]=$chemin.'/'.$nom;
                 $tab['contenu']=$request['contenu'];
                 $tab['date_pub']=strval(date('ymdhis'));
                $this->arRepos->update($id,$tab);
                return redirect()->back();
            }
        
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        echo "ce article sera supprimé";
    }

    public function voir_article($id)
    {
        $article=$this->aRepos->getById($id);

        return view("voirarticle",compact('article'));
    }

    public function articles()
    {
        $all_articles=$this->aRepos->getPaginate($this->nbre_per_page);
        $links=$all_articles->setPath("");
        $nbre=count($all_articles);
        return view("news",compact("all_articles","links","nbre"));
    }

    public function read($id)
    {
        $all_articles=$this->aRepos->getPaginate($this->nbre_per_page);
        $article=$this->aRepos->getById($id);
        return view("ReadArticle", compact("all_articles","article"));
    }
}
