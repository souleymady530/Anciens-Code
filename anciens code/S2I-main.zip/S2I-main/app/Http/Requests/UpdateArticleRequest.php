<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateArticleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     *   
       
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $id=$this->segment(2);
       
            return [
                'id'=>"string|min:7|max:20|Unique:les_articles,id,".$id,
                "titre"=>"required",
                "contenu" =>"required",
                "repertoire_image"=>"required",
            ]; 
         

        
    }
}
