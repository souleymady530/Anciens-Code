<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Les Articles') }}
        </h2>
    </x-slot>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white col-10 offset-1 shadow">
                <h2>Creation d article</h2>

                <form method="POST" action="{{ url('articles') }}" enctype="multipart/form-data">
                    @csrf
                    <label for="Titre">Titre</label>
                    <input type="text" class="form-control" name="titre"/>

                    <label for="repertoire_image">Image</label>
                    <input type="file" class="form-control" name="repertoire_image"/>

                    <label for="contenu">Contenu</label>
                    <textarea name="contenu" id="contenu" cols="30" rows="10" class="form-control"></textarea>
<br>
                    <input type="submit" value="Creer" class="btn btn-success"/>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>

 