@extends("template")

@section("contenu")
<div class="row header" >
    <div class="header-contain">
        <img src="{{url('images/s2i.webp')}}" alt="">
    </div>
</div>
<div class="row ">
    
<div class="col-10 bg-white offset-1 texte_center">
        <h1>{{$article->titre}}</h1>
         <div class="row">
        <img src="/{{$article->repertoire_image}}" alt="">
         </div>

         <div class="row">
            {{$article->contenu}}
         </div>
    </div>
</div>
<style>
    .date-container 
    {
        position:relative;
        top:-5%;
        left:-5%;
        width:150px;
        color:white;
        padding:5px;

        background-color:rgb(9,104,179);
    }
.texte_center
{
   margin-top:-5%;
   font-size:1.4em;
}
.header-contain img
{
    height:100%;
    width:100%;
}
.texte_center h4 
{
    color:rgb(9,104,179);
    font-weight:bold;
}
.texte_center h1
{
    text-align:center;
    font-weight:bold;
    padding:60px;
    color:rgb(9,104,179);
    
}
</style>
@endsection