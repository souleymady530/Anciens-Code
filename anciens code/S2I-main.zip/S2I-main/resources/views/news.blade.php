@extends("template")

@section("contenu")
<div class="row header" >
    <div class="header-contain">
        <img src="images/s2i.webp" alt="">
    </div>
</div>
<div class="row ">
    
<div class="col-10 bg-white offset-1 texte_center">
        <h1>News & Updates</h1>
         <div class="row">

        @php     $i =0;     @endphp
        @foreach($all_articles as $art)
            @php   $class="";      @endphp
            @if($i%2==0)
                @php     $class="offset-1";         @endphp
            @endif
            
            <div class="card col-4 {{$class}} " style="">
                <img src="{{$art->repertoire_image}}" class="card-img-top" alt="...">
                <div class="date-container">
                {{$art->date_pub}}
                </div>
                <div class="card-body ">
                    <h4 class="card-title">{{$art->titre}}</h4><hr>
                    <p class="card-text" style="height:200px;overflow:hidden">
                    {{$art->contenu}}
                    </p>
                    <a href="/read/{{$art->id}}" class="">Read More</a>
                </div>
            </div>
         @endforeach
         </div>
    </div>
</div>
<style>
    .card {
        border:none;

    }
    .card-body{
        border:solid 1px rgb(192,192,192);
        position:relative;
        top:-7%;
        border-top:none;
    }
    .card-img-top
    {
        height:300px;
        width:100%;
    }
    .date-container 
    {
        position:relative;
        top:-5%;
        left:0.1%;
        width:150px;
        color:white;
        padding:5px;

        background-color:rgb(9,104,179);
    }
.texte_center
{
   margin-top:-5%;
   font-size:1.4em;
}
.header-contain img
{
    height:100%;
    width:100%;
}
.texte_center h4 
{
    color:rgb(9,104,179);
    font-weight:bold;
}
.texte_center h1
{
    text-align:center;
    font-weight:bold;
    padding:60px;
    color:rgb(9,104,179);
    
}
</style>
@endsection

@section("menu_news")
menu_actif

@endsection