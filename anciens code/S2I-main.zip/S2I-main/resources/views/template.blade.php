<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

<link rel="apple-touch-icon" sizes="76x76" href="/images/favico/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/images/favico/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/images/favico/favicon-16x16.png">
 <meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">



    <link rel="stylesheet" href="{{url('/customize/style.css')}}"/> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
 <div class="container-fluid">
    <div class="row header_row" style="height:180px">
    <div class="col-2">
      <a class="navbar-brand" href="#">
            <img src="{{url('images/logo.webp')}}" width="100" height="100" alt="">
          </a>
    </div>
     <nav class="col-10">
     
           <ul class="nav justify-content-end">
               <li class="nav-item ">
                 <a class="nav-link  @yield('menu_accueil')" href="{{url('/')}}">Home</a>
               </li>
               <li class="nav-item">
                 <a class="nav-link @yield('menu_about')" href="{{url('/about')}}">About</a>
               </li>
               <li class="nav-item">
                 <a class="nav-link  @yield('menu_news')" href="{{url('/news')}}">News</a>
               </li>
               <li class="nav-item last_item">
                 <a class="nav-link  @yield('menu_contact')" href="{{url('/contact')}}">Contact</a>
               </li>
         </ul>
     </nav>
 


         
    </div>
    <section class="container-fluid">
    @yield("contenu")
</section>




    
        <div class="row footer" style=" ">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 offset-md-1">
              <div class="row">
                <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12  " style="background-color:rgb(9,104,179);color:white">
                  <div class="container">
                      <div class="row">
                          <h3>Contact</h3>
                      </div>
                      <div class="row">
                              <h6>SMART IMPACT INTERNATIONAL</h6>
                      </div>

                      <div class="row texte">
                          <div class="row">
                              <div class="col-6">Registered Charity: 12345-67</div>
                              <div class="col-6">6600 Manton Way <br>Lanham MD 20706</div>
                          
                          </div>
                      </div>
                      <div class="row desc">
                          
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><h4>contact@s2i.org</h4></div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><h4>www.s2i.org</h4></div>
                           
                    </div>
                </div>
            </div>

            <div class="col-lg-3  col-md-12 col-sm-12 col-xs-12 bg-light">
                <img src="{{url('images/logo_footer.webp')}}" width="320" height="320" alt="">
            </div>
            
        </div>
       
            </div>
        </div>
        <div class="row " style="padding:20px;padding-left:45%">
        © 2023 Smart Impact International
        </div>
    
  </div>

  </div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<style>
  .menu_actif
  {
   color:rgb(163,73,164);
  }
  .nav 
  {
    position:relative;
    top:10%;
  }
  .nav-item
  {

    border-right:solid 2px rgb(9,104,179);
    width:230px;
    font-weight:bold;
    text-align:right;
    color:rgb(9,104,179);
  }
  .last_item
  {
    border-right:none;
    
  }
  .footer .container .col-6 h4{
      font-size:2em;
      width:50%;
      border-top:solid 1px white;
  }
  .footer .container .texte 
  {
    font-size:1.2em;
  }

  
  

  
   

    
@media screen and (min-width: 1024px) 
{
  .footer 
    {
        margin-top: 5%;
        
    }

  .header_row
  {
    padding-top:20px;
  }

  .header_row
    {
      margin-bottom:20px;
    }
     
  .footer .container 
    {
      position:relative;
      left:150px;
    }
     
    .footer .container h3
    {
      font-size:3em;
       padding:15px;
       text-align:left;
    }
}
@media screen and (min-device-width: 768px)	and (max-device-width: 1024px)
{
  .footer 
    {
        margin-top: 5%;
        
    }

  .footer .container 
    {
      position:relative;
     
    }


    .header_row
  {
    
    padding-top:20px;
    
  }
  
  .header_row
    {
      
      margin-bottom:20px;
       
    }
   
  .footer .container 
    {
      position:relative;
      left:150px;
    }
     
    .footer .container h3
    {
      font-size:3em;
       padding:15px;
       text-align:left;
    }



}
@media screen and (max-device-width: 480px)	and (orientation: portrait)
{
  .footer 
    {
        margin-top: 10%;
        
    }

  .footer .container 
    {
      position:relative;
      left:10px;
    }
}
</style>