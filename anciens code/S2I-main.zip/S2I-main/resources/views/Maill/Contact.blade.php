<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <h2>Prise de contact sur le site S2I</h2>
    <p>Réception d'une prise de contact avec les éléments suivants :</p>
    <ul>
      <li><strong>Nom</strong> :  </li>
      <li><strong>Email</strong> :  </li>
      <li><strong>Email</strong> :  </li>
      <li><strong>Email</strong> :  </li>
      <li><strong>Message</strong> :  </li>
    </ul>
  </body>
</html>