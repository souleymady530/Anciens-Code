@extends("templates")


@section("contenu")


<div class="row text-center">
    <h3>Prise de contact valider. Vous serez contacter dans de bref delai.</h3>
</div>