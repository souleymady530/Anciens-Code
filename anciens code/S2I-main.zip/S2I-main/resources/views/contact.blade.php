@extends("template")
@section("menu_contact")
menu_actif
@endsection
@section("contenu")
<div class="row header" >
    <div class="header-contain">
        <img src="images/s2i.webp" alt="">
    </div>
</div>
<div class="row ">
    <div class="col-10 bg-white offset-1 texte_center">
        <h1>Coontact Us</h1>
        <div class="row ">
           
            <div class="col-9 offset-1 form_box"> <h4>Volunteer</h4>
                <form action="" class="form_user">

                    <div class="row">
                        <div class="form-group col">
                                <label for="first_name" class="form-control">First Name*</label>
                            <input type="text" class="form-control" id="first_name" required>
                        </div>
                        <div class="form-group col">
                                <label for="last_name" class="form-control">Last Name*</label>
                            <input type="text" class="form-control" id="last_name" required>
                        </div>
                    </div><br>


                    <div class="row">
                        <div class="form-group col">
                                <label for="email" class="form-control">Email*</label>
                            <input type="text" class="form-control" id="email" required>
                        </div>
                        <div class="form-group col">
                                <label for="phone" class="form-control">Phone</label>
                            <input type="text" class="form-control" id="phone">
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="form-group col">
                                <label for="adress" class="form-control">Address</label>
                            <input type="text" class="form-control" id="adress">
                        </div>
                         
                    </div><br>
                  
                    <br>
                    <div class="row">
                    <input class="btn btn-primary btn-lg btn-block" type="submit" value="APPLY"> 
                    </div>
                    
                 </form>
            </div>



            <div class="col-9 offset-1 form_box"> <h4>Partner</h4>
                <form action="" class="form_user">

                    <div class="row">
                        <div class="form-group col">
                                <label for="company" class="form-control">Company</label>
                            <input type="text" class="form-control" id="company">
                        </div>
                        <div class="form-group col">
                                <label for="point" class="form-control">Point of Contact</label>
                            <input type="text" class="form-control" id="point">
                        </div>
                    </div><br>


                    <div class="row">
                        <div class="form-group col">
                                <label for="address" class="form-control">Address</label>
                            <input type="text" class="form-control" id="address">
                        </div>
                        <div class="form-group col">
                                <label for="phone2" class="form-control">Phone*</label>
                            <input type="text" class="form-control" id="phonne2" required>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="form-group col">
                                <label for="media" class="form-control">Social Media Links</label>
                            <input type="text" class="form-control" id="media">
                        </div>
                         
                    </div><br>
                    <br>
                    <div class="row">
                    <input value="SUBMIT" class="btn btn-primary btn-lg btn-block" type="submit"></a>
                    </div>
                    
                 </form>
            </div>


            <div class="col-9 offset-1 form_box form_volunteer"> <h4>Contribute</h4>
                
                
              <h1>Take a part and help us grow</h1>
                
                    <br>
                    <div class="row">
                        <a href="" class="btn_customize col" type="submit">DONATE</a>
                    </div>
                    
                 
            </div>


        </div>
    </div>
 










</div>
<style>
    .form_volunteer{
        padding:25px;
        border:solid 3px rgb(9,104,179);
        
    }
    .form_volunteer .btn_customize
    {
        font-size:2em;
        background-color:rgb(9,104,179);
    }
    .btn_customize
    {
        padding: 15px;
        padding-top: 10px;
        padding-bottom: 10px;
         font-size:1em;
        color:white;
        text-align:center;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
    }

    .form_box {
        margin-bottom:55px;
    }
    .form_box label 
    {
        border:none;
        color:rgb(9,104,179);
    }
    .form_user {
        padding:25px;
        border:solid 3px rgb(9,104,179);
    }
    .form_box input 
    {
        border:none;
        border-bottom:1px solid rgb(9,104,179);
        border-radius:0px;
    }

    

    .form_user .btn-primary{
        font-size:2em;
        background-color:rgb(9,104,179);
    }
    .form-row label 
    {
        border:0;
        color:rgb(9,104,179);
    }
.texte_center
{
   
    margin-top:-5%; 
     
}
.header-contain img
{
    height:100%;
    width:100%;
}
.texte_center h4 
.texte_center {
    color:rgb(9,104,179);
    font-weight:bold;
}
.texte_center h1
{
    text-align:center;
    font-weight:bold;
    padding:60px;
    color:rgb(9,104,179);
    
}
</style>

@endsection