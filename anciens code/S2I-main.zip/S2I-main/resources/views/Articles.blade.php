<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Les Articles') }}
        </h2>
    </x-slot>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <div class="py-12 col-10 offset-1">
            <a href="/articles/create" class="flex justify-end btn btn-info">Creer</a><br><br>
            <div class="col-12">
                <table class="table table-hover table-sttriped ">
                    <tr><th>#</th><th>Article</th> <th>Action</th></tr>
                    <tbody>
                            @foreach($all_articles as $art)

                                <tr>
                                    <td>{{$art->id}}</td>
                                    <td>{{$art->titre}}</td>
                                   
                                     
                                    <td>
                                        <div  class="row">
                                            <a href="/read/{{$art->id}}" class="offset-1 col-3 btn btn-info"  >Voir</a> 
                                            <a href="#" class=" col-3 btn btn-warning" onclick="voir_article( {{$art->id}} )">Editer</a> 
                                            <a class="col-3 btn btn-danger" href=" {{url('Article/')}}/{{$art->id}}"> Supprimer</a> 
                                        </div>
                                    </td>  
                                </tr>
                            @endforeach
                    </tbody>
                </table>
            </div>
            </div>
</x-app-layout>

