@extends("template")
@section("menu_about")
menu_actif
@endsection

@section("contenu")
<div class="row header" >
    <div class="header-contain">
        <img src="images/s2i.webp" alt="">
    </div>
</div>
<div class="row ">
    
<div class="col-10 bg-white offset-1 texte_center">
        <h1>About SMART IMPACT INTERNATIONAL</h1>
        <div class="row ">
            <div class="col-1 d-lg-block d-none">
                <img src="images/logo.webp" alt="">
            </div>
            <div class="col-6 offset-2">

            <h4>Who we are</h4>
                <div class="row">
                   
                    <p>We are a non-profit organization based in Washington DC, U.S.A. dedicated to support development efforts in Burkina Faso.</p>
                </div>



                <h4>Our Principles/policies/guidelines:</h4>
                <div class="row">
                    
                    <p>
                        <ul>
                            <li><strong>Independence</strong>we are an independent organization without political affiliation. Our actions, deliverables and targets are strictly based on our own policies and guidelines. </li>
                            <li><strong>Non discrimination :</strong>We are zero discrimination. Any kind of discrimination is prohibited from our actions. </li>
                            <li><strong>Neutrality:</strong>All victims matter. We guarantee an equal access to our actions without any religious, political and racial consideration. </li>
                            <li><strong>Transparency:</strong>transparency in managing resources is mandatory. We are accountable in keeping partners/donors and beneficiaries informed or aware of our actions. Direct access to beneficiaries is required. </li>
                        </ul>
                    </p>
                </div>


                <h4>Our fields: </h4>
                <div class="row">
                    
                    <p>
                        <ul>
                            <li>Humanitarian Assistance & Legal protection </li>
                            <li>Food security & agriculture </li>
                            <li>Health & nutrition </li>
                            <li> Wash/Protection </li>
                            <li> Youth and Women education/Literacy, training,  empowerment</li>
                            <li>Local agriculture products transformation</li>
                        </ul>   
                    </p>
                </div>



                <h4>Where We work </h4>
                <div class="row">
                 
                     
                        <ul><p>S2I  works in Burkina Faso in</p>  
                    
                            <li>Hauts- Bassins</li>
                            <li>Centre Sud</li>
                        </ul>
                   
                </div>


                <h4>Network </h4>
                <div class="row">
                   
                    <p>
                    <ul>
                            <li>Local organizations and the Government of Burkina Faso.</li>
                            <li>All organizations intervening in the development sector in Burkina Faso</li>
                        </ul>
                    </p>
                </div>


                <div class="row">
                    <a href="" class="col-lg-5 offset-lg-1 col-sm-12 col-xs-12 col-md-4 btn_customize  ">DONATE</a>
                    <a href="" class="col-lg-5  offset-lg-1 col-sm-12 col-xs-12 col-md-7 offset-md-1  btn_customize  ">SEND US EMAIL</a>
                </div>



            </div>
            <div class="col-1 offset-1 d-lg-block d-none"><img src="images/logo.webp" alt=""></div>
        </div>
    </div>
</div>
<style>
    .btn_customize
    {
        margin-top:10px;
        padding: 15px;
        font-size:1em;
        color:white;
        text-decoration:none;
        text-align:center;
        border-radius:0px;
        background-color:rgb(9,104,179);
    }

.texte_center
{
   margin-top:-5%;
   font-size:1.4em;
}
.header-contain img
{
    height:100%;
    width:100%;
}
.texte_center h4 
{
    color:rgb(9,104,179);
    font-weight:bold;
}
.texte_center h1
{
    text-align:center;
    font-weight:bold;
    padding:60px;
    color:rgb(9,104,179);
    
}
</style>
@endsection