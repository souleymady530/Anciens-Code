@extends("template")


@section("menu_accueil")
menu_actif
@endsection

@section("contenu")


    <div class="row header">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
           <div class="row  ">
                <div class="col-12 ">
                    <h1 style="">SMART IMPACT </h1>
                    </div>
                    <div class="col-12 ">
                        <h2 style=" ">INTERNATIONAL</h2>
                    </div>
                
                     <div class="col-8 offset-2 ">
                     <hr style="border:solid 2px blue"/>
                     </div>
                <div class="row" style="font-size:1.6rem;font-weight:bold;">
               
                    <div class="col-lg-2 d-none d-xl-block   ">
                    <img src="images/logo.webp" width="120" height="120" alt="">
                    </div>
                    <div class="col-lg-9 text-center">
                    <p>By an endogenous approach, We build resilient communities  and impact their social changes</p>
                    </div>
                    <div class="col-12">
                        <a href="" class=" offset-5 btn_customize btn_donate_header">DONATE</a> 
                    </div>
                </div>
               
           </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <img src="images/homme-femme-enfant.webp" style="width:100%">
        </div>
    </div>
 

<div class="first_row" style="">

        <div class="row_top_left_box  ">
            <div class="img-box">
                <img src="images/enfant.webp" alt="" >
            </div>
            <div class="text-box">
            <div style="" class="bar_1"></div>
                    <h3>Our fields: </h3>
                    <ul>
                        <li>Humanitarian Assistance & Legal protection </li>
                        <li>Food security & agriculture</li>
                        <li>Health & nutrition</li>
                        <li>Wash/Protection </li>
                        <li>Youth and Women education/Literacy, training,  empowerment</li>
                        <li>Local agriculture products transformation</li>
                    </ul>
                    <a href="" class="btn_customize btn_donate" style="">DONATE</a>
                    <div style=""class="bar_2"></div>

                

            </div>
        </div>

        <div class="row_top_right_box">
            <div class="img-box">
                <img src="images/jeunes.webp" alt="">
            </div>
            <div class="text-box">
                <div style="" class="bar_1"></div>
                <h3>Our Principles/policies/guidelines:</h3>
                <ul>
                        <li>Independence: </li>
                        <li>Non discrimination</li>
                        <li>Neutrality </li>
                        <li>Transparency</li>
                    </ul>
                <a href="" class="btn_customize btn_donate" style="">DONATE</a>
                <div style="" class="bar_2"></div>
            </div>
        </div>
</div>





<div class="second_row" style="">


<div class="row_top_left_box">
            <div class="img-box">
                <img src="images/femme-enfant.webp" alt="">
            </div>
            <div class="text-box">
                <div style="" class="bar_1"></div>
                <h3>Where We work</h3>
                <p> Burkina Faso: Hauts - Bassins, Centre Sud...</p>
                <a href="" class="btn_customize btn_donate" style="">DONATE</a>
                <div style="" class="bar_2"></div>
            </div>
        </div>

        <div class="row_top_right_box  ">
            <div class="img-box">
                <img src="images/homme-femme-enfant.webp" alt="" >
            </div>
            <div class="text-box">
            <div style="" class="bar_1"></div>
            <h3>Our network </h3>
                    <ul>
                        <li>Local organizations and the Government of Burkina Faso.</li>
                        <li>All organizations intervening in the development sector in Burkina Faso</li>
                        
                    </ul>
                    <a href="" class="btn_customize btn_donate" style="">DONATE</a>
                    <div style=""class="bar_2"></div>

                

            </div>
        </div>

</div>


@endsection
<style>
    .header
    {
        padding-bottom:50px;
     }
     

/* For   View */
@media screen and (min-device-width: 1025px)
{
    




    .second_row img 
    {
        height:520px;
    }
    .second_row h3 
    {
        color:rgb(9,104,179);;
        font-weight:bold;
        padding:10px;
        text-align:center;
    }

    .second_row .btn_donate 
    {
        padding: 5px;
        padding-top: 8px;
        padding-bottom: 8px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
        position:relative;
        
        left:65%;
    }
    .second_row
    {
        display:flex;
        justify-content: space-between;
        grid-template-columns: 1fr 1fr 1fr;
         gap: 10px 2em;
         margin-top:-20%;
         margin-bottom:-100px;
     }


     

     .second_row .row_top_left_box{
        width:60%;
     }
     
     .second_row .row_top_right_box{
        width:80%;
     }
     .second_row .row_top_left_box,.second_row .row_top_right_box
     {
       
        font-size:1.2em;

     }

     .second_row .row_top_left_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-30%;
        left:40%;
     }
     .second_row .row_top_left_box .bar_1,.second_row .row_top_left_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
       
     }

      


     .second_row  .row_top_right_box .text-box {
        background-color:white;
        
        width:50%;
        
         
        position:relative;
        top:-55%;
        left:30%;;
     }
     .second_row .row_top_right_box .bar_1,.second_row .row_top_right_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
        position:relative;
        
     }

     .second_row .row_top_right_box .bar_1 
     {
         
        position:relative;
        left:50%;
     }
     
 

    .first_row h3 
    {
        color:rgb(9,104,179);;
        font-weight:bold;
        padding:10px;
        text-align:center;
    }

    .first_row .btn_donate 
    {
        padding: 5px;
        padding-top: 8px;
        padding-bottom: 8px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
        position:relative;
        
        left:65%;
    }
    .first_row
    {
        display:flex;
        justify-content: space-between;
        grid-template-columns: 1fr 1fr 1fr;
         gap: 10px 2em;
     }


     

     .first_row .row_top_left_box{
        width:60%;
     }
     
     .first_row .row_top_right_box{
        width:80%;
     }
     .first_row .row_top_left_box,.first_row .row_top_right_box
     {
       
        font-size:1.2em;

     }

     .row_top_left_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-55%;
     }
     .first_row .row_top_left_box .bar_1,.first_row .row_top_left_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
       
     }

      


     .first_row  .row_top_right_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-55%;
        left:20px;
     }
     .first_row .row_top_right_box .bar_1,.first_row .row_top_right_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
        position:relative;
        
     }

     .first_row .row_top_right_box .bar_1 
     {
         
        position:relative;
        left:50%;
     }
     


     


    .btn_donate_header
    {
        padding: 15px;
        padding-top: 10px;
        padding-bottom: 10px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
    }
    .header h1
    {
        text-align:center;
        color:white;
        background-color:rgb(9,104,179);
        font-weight:bold;
        padding:15px;
        position:relative;
        left:50px;
        width:90%;
        font-size:3em;
    }

    .header h2
    {
        text-align:center;
        color:white;
        background-color:rgb(9,104,179);
        padding:15px;
        font-weight:bold;
        width:80%;
        position:relative;
        left:70px;
        font-size:3em;
    }
}

/* For   tablette View */
@media screen and (min-device-width: 480px)	and (max-device-width: 1024px)
{
    
    
    .first_row h3 
    {
        color:rgb(9,104,179);;
        font-weight:bold;
        padding:10px;
        text-align:center;
    }

    .first_row .btn_donate 
    {
        padding: 5px;
        padding-top: 8px;
        padding-bottom: 8px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
        position:relative;
        
        left:65%;
    }
    .first_row
    {
        display:block;
        justify-content: space-between;
        grid-template-columns: 1fr 1fr 1fr;
         gap: 10px 2em;
     }


     

     
     .first_row .row_top_left_box,.first_row .row_top_right_box
     {
       display:grid;
        font-size:1.2em;

     }

     .first_row .row_top_left_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-105%;
     }
     .first_row .row_top_left_box .bar_1,.first_row .row_top_left_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
       
     }

      


     .first_row .row_top_right_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-105%;
        left:20px;
     }
     .first_row .row_top_right_box .bar_1,.first_row .row_top_right_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
        position:relative;
        
     }

     .first_row .row_top_right_box 
     {
        margin-top:-200px;
     }
     .first_row .row_top_right_box .bar_1 
     {
         
        position:relative;
        left:50%;
     }














     .second_row
    {
        display:block;
        justify-content: space-between;
        grid-template-columns: 1fr 1fr 1fr;
         gap: 10px 2em;
     }




    .second_row h3 
    {
        color:rgb(9,104,179);;
        font-weight:bold;
        padding:10px;
        text-align:center;
    }

    .second_row .btn_donate 
    {
        padding: 5px;
        padding-top: 8px;
        padding-bottom: 8px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
        position:relative;
        
        left:65%;
    }
    
     

     
     .second_row .row_top_left_box,.second_row .row_top_right_box
     {
       display:grid;
        font-size:1.2em;

     }

     .second_row .row_top_left_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-105%;
     }
     .second_row .row_top_left_box .bar_1,.second_row .row_top_left_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
       
     }

      


     .second_row .row_top_right_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-105%;
        left:20px;
     }
     .second_row .row_top_right_box .bar_1,.second_row .row_top_right_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
        position:relative;
        
     }

     .second_row .row_top_right_box 
     {
         
     }
     .second_row .row_top_right_box .bar_1 
     {
         
        position:relative;
        left:50%;
     }



























    .btn_donate_header
    {
        padding: 15px;
        padding-top: 10px;
        padding-bottom: 10px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
    }

    .header h1
    {
        text-align:center;
        color:white;
        background-color:rgb(9,104,179);
        font-weight:bold;
        padding:15px;
        position:relative;
        left:50px;
        width:90%;
        font-size:2em;
    }

    .header h2
    {
        text-align:center;
        color:white;
        background-color:rgb(9,104,179);
        padding:15px;
        font-weight:bold;
        width:80%;
        position:relative;
        left:70px;
        font-size:2em;
    }

    
    
}
    
/* For  Mobile View */
@media screen and (min-device-width: 360px)	and (max-device-width: 480px)
{

    .second_row
    {
        display:block;
        justify-content: space-between;
        grid-template-columns: 1fr 1fr 1fr;
         gap: 10px 2em;
     }



    .second_row h3 
    {
        color:rgb(9,104,179);;
        font-weight:bold;
        padding:10px;
        text-align:center;
    }

    .second_row .btn_donate 
    {
        padding: 5px;
        padding-top: 8px;
        padding-bottom: 8px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
        position:relative;
        
        left:65%;
    }
    

     

     
     .second_row .row_top_left_box,.second_row .row_top_right_box
     {
       display:grid;
         

     }

     .second_row .row_top_left_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-105%;
     }
     .second_row .row_top_left_box .bar_1,.second_row .row_top_left_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
       
     }

      

     .second_row img {
        width:400px;
    }

     .second_row .row_top_right_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-105%;
        left:20px;
     }
     .second_row .row_top_right_box .bar_1,.second_row .row_top_right_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
        position:relative;
        
     }

     .second_row .row_top_right_box 
     {
        margin-top:100px;
     }
     .second_row .row_top_right_box .bar_1 
     {
         
        position:relative;
        left:50%;
     }




















    .first_row img {
        width:400px;
    }
    .first_row h3 
    {
        color:rgb(9,104,179);;
        font-weight:bold;
        padding:10px;
        text-align:center;
    }

    .first_row .btn_donate 
    {
        padding: 5px;
        padding-top: 8px;
        padding-bottom: 8px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
        position:relative;
        
        left:65%;
    }
    .first_row
    {
        display:block;
        justify-content: space-between;
        grid-template-columns: 1fr 1fr 1fr;
         gap: 10px 2em;
         margin-top:150px;
     }


     

     
    .first_row .row_top_left_box,.first_row .row_top_right_box
     {
       display:grid;
         

     }

     .first_row .row_top_left_box .text-box {
        background-color:white;
        
        width:50%;
        
        
        position:relative;
        top:-105%;
     }
     .first_row .row_top_left_box .bar_1,.first_row .row_top_left_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
       
     }

      


     .first_row .row_top_right_box .text-box {
        background-color:white;
        width:60%;
        position:relative;
        top:-105%;
        left:20px;
     }
     .first_row  .row_top_right_box .bar_1,.first_row .row_top_right_box .bar_2
     {
        height:5px;
        width:50%;
        background-color:rgb(9,104,179);
        position:relative;
        
     }

     .first_row .row_top_right_box 
     {
        margin-top:-300px;
     }
     .first_row .row_top_right_box .bar_1 
     {
        position:relative;
        left:50%;
     }


.btn_donate_header
    {
        padding: 15px;
        padding-top: 10px;
        padding-bottom: 10px;
        font-size:1em;
        color:white;
        text-decoration:none;
        border-radius:0px;
        background-color:rgb(9,104,179);
        margin-bottom:15px;
    }

    .header h1
    {
        text-align:center;
        color:white;
        background-color:rgb(9,104,179);
        font-weight:bold;
        padding:15px;
        position:relative;
        left:30px;
        width:90%;
        font-size:2em;
    }

    .header h2
    {
        text-align:center;
        color:white;
        background-color:rgb(9,104,179);
        padding:15px;
        font-weight:bold;
        width:80%;
        position:relative;
        left:45px;
        font-size:2em;
    }

    .header img {
        margin-top:20px;
    }




}





 </style>