# gameForSchool
contient une liste de jeux pour faciliter l'usage des elements de l'ordinateur comme la souris ou le clavier. 
