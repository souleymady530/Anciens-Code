<?php 
 for( $i=0;$i<37;$i++)
	 {
	 
		echo '$("#id-"+alphabet['.$i.']).on("keyup",function(){valider("id-"+alphabet['.$i.']);})<br/>';
	 }
	 