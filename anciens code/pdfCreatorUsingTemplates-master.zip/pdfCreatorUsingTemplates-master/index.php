<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>pdf Creator Using Template </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
	
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />    
   
   
  </head>
  <body class="">
    <div class="row">
	</div>
    <div class="col-lg-12" style="color:white;background-color:orange;height:50px;text-align:center;">
	
	<div class="col-lg-1 col-lg-push-2" style="">
	<a href="index.php" style="">Acceuil</a>
	</div>
	
	<div class="col-lg-1 col-lg-push-2" style="">
	<a href="exemples.php">Exemples</a>
	</div>
	<div class="col-lg-1 col-lg-push-2" style="">
	<a href="modele.php">Modeles</a>
	</div>
	
	</div>
	<style>
	.col-lg-1 a
	{
		text-decoration:none;
		color:white;
		
	}
	.col-lg-1
	{
		margin-top:10px;
	}
	</style>
  </body>
</html>
