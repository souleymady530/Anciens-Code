# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 11:12:03 2023

@author: HP
"""
import numpy  as np
from math import sqrt as racine;
super_matrice=[];
#Decideur 1
decideur_1=[
    
    [4,5,3],
    [1,4,6],
    [2,7,8],
    
    
    ];
lester_1=[2,1,3];



#decideur 2
decideur_2=[
    [5,2,1],
    [3,7,4],
    [6,1,5],
    ];
lester_2=[2,4,2]

#decideur 3
decideur_3=[
    [4,5,5],
    [1,4,2],
    [3,6,1],];


 
lester_3=[2,3,5];

mat=[decideur_1,decideur_2,decideur_3]
mat_lester=[lester_1,lester_2,lester_3]
 
mat_res=[]
mat_denom=[];
for i in range(len(mat_lester)):
    denominateur=sum(mat_lester[i]);
    mat_denom.append(denominateur);
    
    
for i in range(len(mat)):
    decideur=mat[i];
    res_list=[];
    for j in range(len(decideur)):
        numerateur=0;
        for k in range(len(decideur[0])):
            numerateur=numerateur+decideur[j][k]*mat_lester[i][k]
        res_list.append(numerateur)
    mat_res.append(res_list);
    

resultat=np.array(mat_res);
resultat=resultat.T

#print(resultat)
liste_element=[]
for ligne in resultat:
    res=1;
    for element in ligne:
        res=res*element;
    liste_element.append(res);
liste_element=np.array(liste_element);
liste_element=(liste_element)**(1/len(mat))
print(liste_element)




data_array=np.array(mat_res);
data_array=data_array.T
data={}
data_resultat={}
for i in range(len(mat_res)):
    data["A"+str(i+1)]=data_array[i]
    data_resultat["A"+str(i+1)]=liste_element[i]


mat_res.append(liste_element)
mat_res=np.array(mat_res);
mat_res=mat_res.T

data_resultat=dict(sorted(data_resultat.items(),reverse=True))
data_res={}
for key in data_resultat.keys():
    data_res[key]=list(data[key]);
    data_res[key].append(data_resultat[key])


for key,value in data_res.items():
    line=""
    for element in value:
        line=line+"---"+str(element);
    print(key,"==>",line)
    
    

