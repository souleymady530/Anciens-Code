import openpyxl


def load_data(nom_fichier):
    #lecture 
    workbook = openpyxl.load_workbook(nom_fichier, read_only = True)
    data=[]
    
    data_lester=[]
    for sheet in workbook:
        data_decideur=[]
        
        i=0;
        for row in sheet:
            liste_temporaire=[]
            liste_lester_temp=[]
            for cell in row:
                if i==0 :
                    liste_lester_temp.append(cell.value);
                else:
                    liste_temporaire.append(cell.value)
            i+=1
            data_decideur.append(liste_temporaire)
            if(len(liste_lester_temp)>0):
                data_lester.append(liste_lester_temp)
       
        data.append(data_decideur[1:]);
    #fermeture
    workbook.close()
    return (data,data_lester);

 