# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 08:30:44 2023

@author: HP
"""
import numpy  as np
from math import sqrt as racine;
super_matrice=[];
#Decideur 1
decideur_1=[
    
    [4,5,3],
    [1,4,6],
    [2,7,8],
    
    
    ];
lester_1=[2,1,3];



#decideur 2
decideur_2=[
    [5,2,1],
    [3,7,4],
    [6,1,5],
    ];
lester_2=[2,4,2]

#decideur 3
decideur_3=[
    [4,5,5],
    [1,4,2],
    [3,6,1],];



lester_3=[2,3,5];

mat=[decideur_1,decideur_2,decideur_3]
mat_lester=[lester_1,lester_2,lester_3]
 
mat_res=[]
mat_denom=[];
for i in range(len(mat_lester)):
    denominateur=sum(mat_lester[i]);
    mat_denom.append(denominateur);
    
    
    
for i in range(len(mat)):
    decideur=mat[i];
    res_list=[];
    for j in range(len(decideur)):
        numerateur=0;
        for k in range(len(decideur[0])):
            numerateur=numerateur+decideur[j][k]*mat_lester[i][k]
        res_list.append(numerateur/mat_denom[i])
    mat_res.append(res_list);
#print(mat_res)
resultat=np.array(mat_res);
resultat=resultat.T


resultat=resultat**2;
liste_som=[sum(ligne) for ligne in resultat]
liste_som=np.array(liste_som);

Mat_MACUQ=[racine(element/len(mat)) for element in liste_som]


#print(Mat_MACUQ)
dico={}
dico_data={}
data_array=np.array(mat_res).T
for i in range(len(liste_som)):
    dico_data["A"+str(i+1)]=data_array[i]
    
#print(dico_data)  
    
for i in range(len(Mat_MACUQ)):
    dico["A"+str(i+1)]=Mat_MACUQ[i]
     
 
dico_1=dict(sorted(dico.items(),reverse=True))
#print(dico_1);



Mat_MACUQ=np.array(Mat_MACUQ)
mat_res.append(Mat_MACUQ);
mat_res=np.array(mat_res);
mat_res=mat_res.T
#print(mat_res)
#print("*"*30)

mat_res.sort(axis=1)
#print(mat_res);




dico_resultat={}

for key in dico_1.keys():
    dico_resultat[key]=list(dico_data[key]);
    dico_resultat[key].append(dico_1[key])

for key,value in dico_resultat.items():
    line=""
    for element in value:
        line=line+"---"+str(element)
    print(key+"==>",line)
    
    
    
    
"""
#mat_res=resultat
#print(Mat_MACUQ)

#Mat_MACUQ=racine(liste_som/len(mat))
#print(Mat_MACUQ)


for ligne in resultat:
    liste_som.append(sum(ligne))
print(liste_som)
#print(resultat)
"""





















"""

for i in range(len(decideur_1)):
   
    for j in range(len(mat)):
        denominateur=sum(mat_lester[j]);
        numerateur=0;
        for k in range(len(mat[i][j])):
            numerateur=numerateur+mat[i][j][k]*mat_lester[i][j];
        print("--"*20);
        print(numerateur)

    print("--"*20);
    print(numerateur)
    
    
    
    
    res_list.append(numerateur/mat_denom[i])
        mat_res.append(res_list);
 


resultat=np.array(mat_res);

for i in range(len(resultat)):
    for j in range(len(resultat[0])):
        print(resultat[i][j])
    print("--"*30)





        """
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    