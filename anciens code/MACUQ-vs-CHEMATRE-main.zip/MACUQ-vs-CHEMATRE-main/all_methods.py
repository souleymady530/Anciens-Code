# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 13:55:04 2023

@author: HP
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 08:30:44 2023

@author: HP
"""
import numpy  as np
from math import sqrt as racine;
import load_data
print("*"*90)
print("METHODE MACUQ")
print("*"*90)
super_matrice=[];
#Decideur 1
 

# Creation d'une super matrice pour regrouper toutes les matrice
"""
mat=[decideur_1,decideur_2,decideur_3]

mat_lester=[lester_1,lester_2,lester_3]"""

mat,mat_lester=load_data.load_data('data/data.xlsx')

#Matrice contenant les lesters

mat_res=[]
mat_denom=[];

#La somme des lesters
#par exemple la somme des lesters du premier decideurs, 
#ensuite le deuxieme et le troisieme pour un nombre de decideur egale 3
#Pour la formule du macuq il faut faire la somme des lesters pour chaque decideur
#a la fin de cette boucle on aura une liste d elements dont chaque element est la somme des lester du decideur

for i in range(len(mat_lester)):
    denominateur=sum(mat_lester[i]);
    mat_denom.append(denominateur);
    
 #la formule du produit  
    
for i in range(len(mat)):
    decideur=mat[i];
    res_list=[];
    for j in range(len(decideur)):
        numerateur=0;
        
#Calcul du numerateur
        
        for k in range(len(decideur[0])):
            numerateur=numerateur+decideur[j][k]*mat_lester[i][k]
        res_list.append(numerateur/mat_denom[i])
    mat_res.append(res_list);
    
#Pour convertir la liste en matrice

resultat=np.array(mat_res);
resultat=resultat.T

# Mise au carre element par element

resultat=resultat**2;
liste_som=[sum(ligne) for ligne in resultat]
liste_som=np.array(liste_som);

# calcul de la racine

Mat_MACUQ=[racine(element/len(mat)) for element in liste_som]


#print(Mat_MACUQ)
dico={}
dico_data={}
data_array=np.array(mat_res).T
for i in range(len(liste_som)):
    dico_data["A"+str(i+1)]=data_array[i]
    
#print(dico_data)  
    
for i in range(len(Mat_MACUQ)):
    dico["A"+str(i+1)]=Mat_MACUQ[i]
     
 
dico_1=dict(sorted(dico.items(),reverse=True))
#print(dico_1);



Mat_MACUQ=np.array(Mat_MACUQ)
mat_res.append(Mat_MACUQ);
mat_res=np.array(mat_res);
mat_res=mat_res.T
#print(mat_res)
#print("*"*30)

mat_res.sort(axis=1)
#print(mat_res);




dico_resultat={}

for key in dico_1.keys():
    dico_resultat[key]=list(dico_data[key]);
    dico_resultat[key].append(dico_1[key])

for key,value in dico_resultat.items():
    line=""
    for element in value:
        line=line+"---"+str(element)
    print(key+"==>",line)
    
print("*"*90)
print("METHODE CHEMATRE")
print("*"*90)

mat_res=[]
mat_denom=[];
for i in range(len(mat_lester)):
    denominateur=sum(mat_lester[i]);
    mat_denom.append(denominateur);
    
    
for i in range(len(mat)):
    decideur=mat[i];
    res_list=[];
    for j in range(len(decideur)):
        numerateur=0;
        for k in range(len(decideur[0])):
            numerateur=numerateur+decideur[j][k]*mat_lester[i][k]
        res_list.append(numerateur)
    mat_res.append(res_list);
    

resultat=np.array(mat_res);
resultat=resultat.T

#print(resultat)
liste_element=[]
for ligne in resultat:
    res=1;
    for element in ligne:
        res=res*element;
    liste_element.append(res);
liste_element=np.array(liste_element);
liste_element=(liste_element)**(1/len(mat))
print(liste_element)




data_array=np.array(mat_res);
data_array=data_array.T
data={}
data_resultat={}
for i in range(len(mat_res)):
    data["A"+str(i+1)]=data_array[i]
    data_resultat["A"+str(i+1)]=liste_element[i]


mat_res.append(liste_element)
mat_res=np.array(mat_res);
mat_res=mat_res.T

data_resultat=dict(sorted(data_resultat.items(),reverse=True))
data_res={}
for key in data_resultat.keys():
    data_res[key]=list(data[key]);
    data_res[key].append(data_resultat[key])


for key,value in data_res.items():
    line=""
    for element in value:
        line=line+"---"+str(element);
    print(key,"==>",line)