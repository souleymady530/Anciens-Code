package com.deliverooapi.src;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliverooApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
